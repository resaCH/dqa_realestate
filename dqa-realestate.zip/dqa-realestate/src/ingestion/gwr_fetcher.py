"""
src/ingestion/gwr_fetcher.py
-----------------------------
Client für das Gebäude- und Wohnungsregister (GWR) der Schweiz.
API-Dokumentation: https://www.housing-stat.ch/de/madd/public.html

Wichtige Konzepte:
- EGID  = Eidgenössischer Gebäudeidentifikator (eindeutig pro Gebäude)
- EWID  = Eidgenössischer Wohnungsidentifikator (eindeutig pro Wohnung)
- GDAT  = Datum der letzten Mutierung → Basis für inkrementellen Abzug
- GSTAT = Gebäudestatus (1=geplant, 2=bewilligt, 3=im Bau, 4=bewohnt, 8=abgebrochen)
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Iterator

import requests
from loguru import logger
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from src.utils.config import settings


# GWR API Felder (Auswahl relevanter Gebäude-Attribute)
GWR_BUILDING_FIELDS = [
    "egid",       # Gebäudeidentifikator
    "gdekt",      # Kantonskürzel
    "ggdenr",     # BFS-Gemeindenummer
    "ggdename",   # Gemeindename
    "egrid",      # Grundstücksidentifikator
    "lgbkr",      # Gebäudekreis
    "lparz",      # Parzellennummer
    "gstat",      # Gebäudestatus
    "gkat",       # Gebäudekategorie
    "gklas",      # Gebäudeklasse
    "gbauj",      # Baujahr
    "gbaum",      # Baumonat
    "gbaup",      # Bauperiode
    "gabbj",      # Abbruchjahr
    "garea",      # Gebäudefläche (m²)
    "gvol",       # Gebäudevolumen (m³)
    "ganzwhg",    # Anzahl Wohnungen
    "gazzi",      # Anzahl Zimmer
    "gschutzr",   # Schutzraum vorhanden
    "gdatns",     # Einreisedatum ins Register
    "gdat",       # Datum letzte Mutation
    "strname",    # Strassenname
    "deinr",      # Eingangsnummer
    "plz4",       # Postleitzahl
    "plzname",    # PLZ-Ort
    "gkode",      # Eidg. Gebäudekoordinate E
    "gkodn",      # Eidg. Gebäudekoordinate N
]


@dataclass
class GWRRecord:
    """Ein einzelner GWR-Datensatz (Gebäude)."""
    data: dict
    raw_response: dict = field(default_factory=dict, repr=False)


class GWRFetcher:
    """
    Fetcht Gebäudedaten vom GWR REST API.

    Unterstützt:
    - Vollabzug aller Gebäude (optional gefiltert nach Kanton)
    - Inkrementellen Abzug ab einem Mutierungsdatum (GDAT >= watermark)
    - Automatische Pagination
    - Retry bei Netzwerkfehlern
    """

    BASE_URL = settings.gwr_base_url
    PAGE_SIZE = 500  # API-Maximum

    def __init__(self, kanton: str = "") -> None:
        self.kanton = kanton or settings.gwr_kanton
        self.session = requests.Session()
        self.session.headers.update(
            {"Accept": "application/json", "User-Agent": "dqa-realestate/1.0"}
        )

    # ------------------------------------------------------------------
    # Öffentliche API
    # ------------------------------------------------------------------

    def fetch_buildings(
        self,
        since_date: str | None = None,
        max_records: int | None = None,
    ) -> Iterator[dict]:
        """
        Liefert Gebäude-Records als Iterator.

        Args:
            since_date: Nur Gebäude mit GDAT >= dieses Datum (Format: YYYY-MM-DD).
                        None = Vollabzug.
            max_records: Maximale Anzahl Records (nur für Tests).

        Yields:
            dict mit allen GWR-Feldern + Metadaten.
        """
        offset = 0
        total_fetched = 0
        logger.info(
            f"GWR Gebäude-Abzug gestartet | "
            f"Kanton={self.kanton or 'alle'} | "
            f"since={since_date or 'Vollabzug'}"
        )

        while True:
            params = self._build_params(since_date, offset)
            response = self._get(f"{self.BASE_URL}/buildings", params=params)
            records = response.get("buildings", [])

            if not records:
                logger.info(f"Keine weiteren Records. Total: {total_fetched}")
                break

            for record in records:
                if max_records and total_fetched >= max_records:
                    return
                yield self._normalize_building(record)
                total_fetched += 1

            logger.debug(f"Batch abgerufen: offset={offset}, batch={len(records)}")

            # API paginiert via Offset
            if len(records) < self.PAGE_SIZE:
                logger.info(f"Letzter Batch erreicht. Total: {total_fetched}")
                break

            offset += self.PAGE_SIZE
            time.sleep(0.2)  # Rate-Limiting respektieren

    def fetch_apartments(
        self,
        egid: int,
    ) -> list[dict]:
        """
        Liefert alle Wohnungen (EWID) eines bestimmten Gebäudes (EGID).
        """
        response = self._get(
            f"{self.BASE_URL}/buildings/{egid}/apartments"
        )
        return [
            self._normalize_apartment(a)
            for a in response.get("apartments", [])
        ]

    def test_connection(self) -> bool:
        """Testet die API-Verbindung mit einem minimalen Request."""
        try:
            params = {"limit": 1}
            self._get(f"{self.BASE_URL}/buildings", params=params)
            logger.info("GWR API-Verbindung: OK")
            return True
        except Exception as exc:
            logger.error(f"GWR API-Verbindung fehlgeschlagen: {exc}")
            return False

    # ------------------------------------------------------------------
    # Interne Hilfsmethoden
    # ------------------------------------------------------------------

    def _build_params(self, since_date: str | None, offset: int) -> dict:
        params: dict = {
            "limit": self.PAGE_SIZE,
            "offset": offset,
        }
        if self.kanton:
            params["gdekt"] = self.kanton
        if since_date:
            params["gdatMin"] = since_date  # GWR-Parameter für GDAT >= Datum
        return params

    @retry(
        retry=retry_if_exception_type((requests.Timeout, requests.ConnectionError)),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        stop=stop_after_attempt(5),
    )
    def _get(self, url: str, params: dict | None = None) -> dict:
        response = self.session.get(url, params=params, timeout=30)
        if response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", 10))
            logger.warning(f"Rate-Limit erreicht. Warte {retry_after}s...")
            time.sleep(retry_after)
            response = self.session.get(url, params=params, timeout=30)
        response.raise_for_status()
        return response.json()

    @staticmethod
    def _normalize_building(raw: dict) -> dict:
        """Normalisiert einen rohen API-Record auf einheitliche Feldnamen."""
        return {
            # Identifikatoren
            "egid":      _int(raw.get("egid")),
            "egrid":     raw.get("egrid"),
            # Ort
            "gdekt":     raw.get("gdekt"),       # Kanton
            "ggdenr":    _int(raw.get("ggdenr")), # Gemeindenummer
            "ggdename":  raw.get("ggdename"),    # Gemeindename
            "strname":   raw.get("strname"),
            "deinr":     raw.get("deinr"),
            "plz4":      raw.get("plz4"),
            "plzname":   raw.get("plzname"),
            # Status & Kategorie
            "gstat":     _int(raw.get("gstat")),
            "gkat":      _int(raw.get("gkat")),
            "gklas":     _int(raw.get("gklas")),
            # Baujahr / Abbruch
            "gbauj":     _int(raw.get("gbauj")),
            "gbaum":     _int(raw.get("gbaum")),
            "gbaup":     _int(raw.get("gbaup")),
            "gabbj":     _int(raw.get("gabbj")),
            # Masse
            "garea":     _float(raw.get("garea")),
            "gvol":      _float(raw.get("gvol")),
            "ganzwhg":   _int(raw.get("ganzwhg")),
            "gazzi":     _int(raw.get("gazzi")),
            # Koordinaten
            "gkode":     _float(raw.get("gkode")),
            "gkodn":     _float(raw.get("gkodn")),
            # Schutz
            "gschutzr":  _int(raw.get("gschutzr")),
            # Datum
            "gdatns":    raw.get("gdatns"),
            "gdat":      raw.get("gdat"),        # Mutierungsdatum → Watermark
        }

    @staticmethod
    def _normalize_apartment(raw: dict) -> dict:
        return {
            "egid":    _int(raw.get("egid")),
            "ewid":    _int(raw.get("ewid")),
            "whgnr":   raw.get("whgnr"),
            "wstwk":   _int(raw.get("wstwk")),    # Stockwerk
            "wbez":    raw.get("wbez"),            # Lage
            "wstat":   _int(raw.get("wstat")),     # Wohnungsstatus
            "wkat":    _int(raw.get("wkat")),
            "wazim":   _int(raw.get("wazim")),     # Zimmeranzahl
            "warea":   _float(raw.get("warea")),   # Fläche
            "wkche":   _int(raw.get("wkche")),     # Küche
        }


# ------------------------------------------------------------------
# Hilfsfunktionen für Typ-Konvertierung
# ------------------------------------------------------------------

def _int(value) -> int | None:
    try:
        return int(value) if value is not None else None
    except (ValueError, TypeError):
        return None


def _float(value) -> float | None:
    try:
        return float(value) if value is not None else None
    except (ValueError, TypeError):
        return None
