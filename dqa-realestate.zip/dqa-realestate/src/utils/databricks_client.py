"""
src/utils/databricks_client.py
-------------------------------
Wrapper um das Databricks SDK.
Stellt eine Verbindung bereit und kapselt häufige Operationen
(SQL ausführen, Delta-Tabellen anlegen, Daten schreiben).
"""

from __future__ import annotations

from typing import Any

import pandas as pd
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.sql import StatementState
from loguru import logger

from src.utils.config import settings


class DatabricksClient:
    """Zentraler Client für alle Databricks-Operationen."""

    def __init__(self) -> None:
        self._ws = WorkspaceClient(
            host=settings.databricks_host,
            token=settings.databricks_token,
        )
        self.catalog = settings.databricks_catalog
        self.schema = settings.databricks_schema
        self._warehouse_id: str | None = None
        logger.info(
            f"Databricks-Client initialisiert: {settings.databricks_host} | "
            f"{self.catalog}.{self.schema}"
        )

    # ------------------------------------------------------------------
    # Warehouse
    # ------------------------------------------------------------------

    def get_warehouse_id(self) -> str:
        """Gibt die ID des ersten verfügbaren SQL Warehouse zurück."""
        if self._warehouse_id:
            return self._warehouse_id
        warehouses = list(self._ws.warehouses.list())
        if not warehouses:
            raise RuntimeError("Kein SQL Warehouse im Workspace gefunden.")
        self._warehouse_id = warehouses[0].id
        logger.debug(f"SQL Warehouse: {self._warehouse_id}")
        return self._warehouse_id

    # ------------------------------------------------------------------
    # SQL
    # ------------------------------------------------------------------

    def execute_sql(self, sql: str, wait_timeout: str = "30s") -> list[dict[str, Any]]:
        """Führt ein SQL-Statement aus und gibt die Zeilen als Liste zurück."""
        logger.debug(f"SQL:\n{sql}")
        statement = self._ws.statement_execution.execute_statement(
            warehouse_id=self.get_warehouse_id(),
            statement=sql,
            wait_timeout=wait_timeout,
        )
        if statement.status.state != StatementState.SUCCEEDED:
            raise RuntimeError(
                f"SQL fehlgeschlagen [{statement.status.state}]: "
                f"{statement.status.error}"
            )
        if not statement.result or not statement.result.data_array:
            return []
        columns = [col.name for col in statement.manifest.schema.columns]
        return [dict(zip(columns, row)) for row in statement.result.data_array]

    def execute_sql_no_result(self, sql: str) -> None:
        """Führt DDL / DML ohne Rückgabewert aus."""
        self.execute_sql(sql)

    # ------------------------------------------------------------------
    # Schema / Tabellen
    # ------------------------------------------------------------------

    def ensure_schema(self) -> None:
        """Erstellt Catalog + Schema falls nicht vorhanden."""
        self.execute_sql_no_result(
            f"CREATE SCHEMA IF NOT EXISTS {self.catalog}.{self.schema}"
        )
        logger.info(f"Schema sichergestellt: {self.catalog}.{self.schema}")

    def table_exists(self, table_name: str) -> bool:
        rows = self.execute_sql(
            f"""
            SELECT COUNT(*) AS cnt
            FROM {self.catalog}.information_schema.tables
            WHERE table_schema = '{self.schema}'
              AND table_name   = '{table_name}'
            """
        )
        return rows[0]["cnt"] > 0 if rows else False

    # ------------------------------------------------------------------
    # Daten schreiben
    # ------------------------------------------------------------------

    def write_dataframe(
        self,
        df: pd.DataFrame,
        table_name: str,
        mode: str = "append",
    ) -> None:
        """
        Schreibt einen Pandas DataFrame in eine Delta-Tabelle.
        mode: 'append' | 'overwrite'
        """
        full_name = f"{self.catalog}.{self.schema}.{table_name}"
        from databricks.connect import DatabricksSession

        spark = (
            DatabricksSession.builder.sdkConfig(self._ws.config).getOrCreate()
        )
        spark_df = spark.createDataFrame(df)
        spark_df.write.format("delta").mode(mode).option(
            "mergeSchema", "true"
        ).saveAsTable(full_name)
        logger.info(f"Geschrieben ({mode}): {full_name} — {len(df)} Zeilen")


# Singleton
_client: DatabricksClient | None = None


def get_client() -> DatabricksClient:
    global _client
    if _client is None:
        _client = DatabricksClient()
    return _client
